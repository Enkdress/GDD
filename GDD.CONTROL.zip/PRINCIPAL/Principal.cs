﻿using System;
using System.IO;
using System.Text;
using GDD.VISTA;
using iText.IO.Util;

namespace PRINCIPAL
{
    class Principal
    {
        /// <summary>
        ///  The main entry point for the application.
        /// </summary>
        [STAThread]
        static void Main(string[] args)
        {
            Console.WriteLine("INITIALISING APPLICATION...!");
            Program.Main();
        }
    }
}
